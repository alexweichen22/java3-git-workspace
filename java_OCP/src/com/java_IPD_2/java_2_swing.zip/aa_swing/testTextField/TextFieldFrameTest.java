package java2ch12.pkg6;

public class TextFieldFrameTest {

    public static void main(String[] args) {
        Java2ch126 tff1 = new Java2ch126 ();
        
        
    }
    
}
