package _java_exe.java2Ch12Ex10.src.colorSelect;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JCombobox;




public class ColorSelect {
    public final int WIDTH = 600;
    public final int HEIGHT = 400;

    public static void main(String[] args) {
        JFrame jframe = new JFrame("ColorSelect");
        jframe.setVisible(true);
        jframe.setLayout();

        JCombobox jcombobox = new JCombobox();

        jframe.add(jcombobox);




    }

}
