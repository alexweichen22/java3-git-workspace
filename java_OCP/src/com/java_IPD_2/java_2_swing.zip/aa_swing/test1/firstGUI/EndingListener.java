package _java_exe.java2aGUI.src.firstGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class EndingListener implements ActionListener {
    public void actionPerformed(ActionEvent e){
        System.exit(0);
    }

}
