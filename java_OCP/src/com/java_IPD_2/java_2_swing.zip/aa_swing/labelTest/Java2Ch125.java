package java2ch12.pkg5;

public class Java2Ch125 {


    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}

