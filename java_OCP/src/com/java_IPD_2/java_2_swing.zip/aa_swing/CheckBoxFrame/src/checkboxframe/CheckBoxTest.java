package _java_exe.CheckBoxFrame.src.checkboxframe;

// Fig. 12.18: CheckBoxTest.java
// Testing CheckBoxFrame.
import javax.swing.JFrame;

public class CheckBoxTest
 {
 public static void main(String[] args)
 {
 CheckBoxFrame checkBoxFrame = new CheckBoxFrame();
 checkBoxFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 checkBoxFrame.setSize(275, 100);
 checkBoxFrame.setVisible(true);
 }
 } // end class CheckBoxTest
