/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package _java_exe.java2Exe3.src.main.java.com.jac.p2example3;
/**
 *
 * @author 6151742
 */
public interface IVehicle {
    boolean CAN_START = true;            // Only final varialbe can be set in interface!!!
    void start();
    void stop();    
}
