package _java_exe.stringReverse.src.stringreverse;

public class ValidateInput {
    
 // validate first name
 public static boolean validateEmail(String emailAddress)
 {
     return emailAddress.matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$");
    
 }

}


