package _java_exe.java2Exe7Assignment1a.src.main.java.com;

public class MyToyota extends Car{
    
    @override
    public void addLicense(String license){
        System.out.println("Test addLicense");
    }
    
    @override    
    public void removeLicense(String license){
        System.out.println("Test removeLicense");
    }
    
}
