package _java_exe.java2Exe7Assignment1a.src.main.java.com;

public class Car {
    // Declare Varialbes
    private String make;
    private String color;

    // Getter
    public String getMake() {return make;}
    public String getColor(){return color;}

    
    // Setter
    public void setMake(String make) {this.make = make;}
    public void setColor(String color){this.color = color;}
        
 
    
  

}
