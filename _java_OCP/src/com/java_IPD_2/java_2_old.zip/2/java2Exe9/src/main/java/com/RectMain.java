package _java_exe.java2Exe9.src.main.java.com;
import java.util.Scanner;
public class RectMain {
    
    public static void main(String[] args) {
        
        System.out.println("Hello");
//        Scanner input = new Scanner(System.in);              
//        Rectangle rect1 = new Rectangle();
//        System.out.println("Enter the length of the rectangle:");
//        rect1.setLength(input.nextInt());
//        System.out.println("Enter the width of the rectangle"); 
//        rect1.setWidth(input.nextInt());
//        rect1.printArea();
//        rect1.printPerimeter();
        
               
        // Play with inheritance
//        rect.printX();
//        rect.setPolyNumber(4);                  
        
    }
    
}
