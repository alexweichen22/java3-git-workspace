package _java_exe.java2Exe9.src.main.java.com;

public interface IShape {
    public double calculatePerimeter();
    public double calculateArea();
    public void printX(double value);
    
}
