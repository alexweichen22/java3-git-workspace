package _java_exe.java2Exe9.src.main.java.com.mycompany.java2exe9;

public class Shape {
    
}
