package _java_exe.java2Exe9.src.main.java.com;

public interface InterfaceX {
    default void printX(){
        System.out.println("This is to test my default interface");
    }
}
