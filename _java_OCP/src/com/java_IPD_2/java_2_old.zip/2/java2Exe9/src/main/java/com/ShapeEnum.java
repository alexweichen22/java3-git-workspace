package _java_exe.java2Exe9.src.main.java.com;

public enum ShapeEnum {
    Triagle,Rectangle, Round;
}
