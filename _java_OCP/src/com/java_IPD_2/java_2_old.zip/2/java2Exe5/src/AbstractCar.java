package _java_exe.java2Exe5.src;

abstract class AbstractCar {
    public abstract void addPlate();
}
