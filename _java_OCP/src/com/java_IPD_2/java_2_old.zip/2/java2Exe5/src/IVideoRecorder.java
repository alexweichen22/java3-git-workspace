package _java_exe.java2Exe5.src;

public interface IVideoRecorder {
    public abstract void record();
}
