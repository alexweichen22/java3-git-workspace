package _java_exe.InterfaceTest.src.interfacetest;

interface TestInterface1 {

    default void show() {
        System.out.println("test 1");
    }
}
