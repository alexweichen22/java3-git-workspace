package _java_exe.InterfaceTest.src.interfacetest;

interface TestInterface2 {

    default void show() {
        System.out.println("test 2");
    }
}
