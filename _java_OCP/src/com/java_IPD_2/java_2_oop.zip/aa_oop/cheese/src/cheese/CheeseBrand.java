package _java_exe.cheese.src.cheese;

public class CheeseBrand {
    private String brandX;
    
    // Constructor
    CheeseBrand(String brand){
    this.brandX=brand;
    }
    
    public void setBrandX(String brand){
        this.brandX=brand;
    }
    public String getBrandX(){
        return this.brandX;
    }    
}
