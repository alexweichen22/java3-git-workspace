package _java_exe.cheese.src.cheese;

public interface InterfaceCheese {    // Abstraction
    void setWeight(double weight);    
}
