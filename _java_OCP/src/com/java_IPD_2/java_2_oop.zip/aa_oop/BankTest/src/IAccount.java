package _java_exe.BankTest.src;

public interface IAccount {

    public void withdraw(double amt);

    public void deposit(double amt);
}
