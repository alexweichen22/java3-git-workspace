package _java_exe.BankTest.src.banktest;

public interface IAccount {

    public void withdraw(double amt);

    public void deposit(double amt);
}
