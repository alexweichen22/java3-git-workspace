package _java_exe.BankTest.src;

public enum Currency {

    USD, CAD, EUR
}
