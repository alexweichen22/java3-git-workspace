package _java_exe.BankTest.src.banktest;

public class Saving implements IAccount {

    protected double savingBalances;
    private Currency savingCur;

    @Override
    public void withdraw(double amt) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deposit(double amt) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
