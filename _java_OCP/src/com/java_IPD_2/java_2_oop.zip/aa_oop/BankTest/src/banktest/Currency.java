package _java_exe.BankTest.src.banktest;

public enum Currency {

    USD, CAD, EUR
}
