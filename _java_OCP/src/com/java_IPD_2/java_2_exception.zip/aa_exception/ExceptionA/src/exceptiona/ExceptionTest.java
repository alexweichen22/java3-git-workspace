package _java_exe.ExceptionA.src.exceptiona;

import java.lang.Exception;
import java.io.IOException;

public class ExceptionTest {
    public static void main(String[] args) {
        System.out.println("Hello World");
//        //ExceptionA excepA = new ExceptionA("Message from A");
//        //ExceptionB excepB = new ExceptionB("Message from B");
//
//        try {
//              throw new Exception("Type Exception");
////            throw new ExceptionA("Type ExceptionA");
////            throw new ExceptionB("Type ExceptionB");
////            throw new NullPointerException("Type NullPointerException");
////            throw new IOEException("Type IOEException");
//        } catch (Exception ex) {
//            System.out.println("Exception");
//            ex.printStackTrace;
//        } catch (ExceptionA exA) {
//            System.out.println("ExceptionA");
//            exA.printStackTrace;
//        } catch (ExceptionB exB) {
//            System.out.println("ExceptionB");
//            exB.printStackTrace;
//        } catch (NullPointerException nullExcep) {
//            System.out.println("NullPointerException");
//            nullExcep.printStackTrace;
//        } catch (IOEException ioeExcep) {
//            System.out.println("IOEException");
//            ioeExcep.printStackTrace;
//        }
    }
}
