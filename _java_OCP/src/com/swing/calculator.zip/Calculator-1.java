package com.swing;
class Calculator {
	public static void main(String[] args){
		testSum(5,7);
	}
	static void testSum(int x,int y){
		System.out.println("The sum of "+ x + " and " +y+" is: " + (x+y));


	}
}


