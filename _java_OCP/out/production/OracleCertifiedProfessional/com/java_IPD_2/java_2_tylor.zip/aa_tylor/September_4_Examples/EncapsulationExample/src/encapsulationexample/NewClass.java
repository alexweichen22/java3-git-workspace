/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package _java_exe.September_4_Examples.EncapsulationExample.src.encapsulationexample;

import java.util.Scanner;

/**
 *
 * @author 1896217
 */
public class NewClass {
    public void example() {
        Scanner s = new Scanner(System.in);        
        Capsule cap = new Capsule();
        
        
    }
}
