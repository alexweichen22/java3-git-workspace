package _java_exe.java2TA1.src.main.java.myPackage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 6151742
 */
import java.util.Scanner;
public class CompanyManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Scanner 
//        Customer cust = new Customer();
        
        System.out.println("Enter customer name");
        
   
    
        
    }
    
}
