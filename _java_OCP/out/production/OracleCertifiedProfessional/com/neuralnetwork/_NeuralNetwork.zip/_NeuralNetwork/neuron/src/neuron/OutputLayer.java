/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuron;

/**
 *
 * @author Chen
 */
public class OutputLayer extends Layer{
    public void initLayer (OutputLayer outputLayer){
        // Initializes output layer with pseudo random real numbers
    }

public void printLayer(OutputLayer outputLayer){
    // print the weights of the layer
}
    
}
