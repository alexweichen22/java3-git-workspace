/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuron;

/**
 *
 * @author Chen
 */
public class InputLayer extends Layer {
    public void initLayer(InputLayer inputLayer){
    // Initiate the input layer with Attribute ( object of InputLayer)
    // No return value
    }

public void printLayer(InputLayer inputLayer){
    // print the input weithts of the layer
}



    
    

}
