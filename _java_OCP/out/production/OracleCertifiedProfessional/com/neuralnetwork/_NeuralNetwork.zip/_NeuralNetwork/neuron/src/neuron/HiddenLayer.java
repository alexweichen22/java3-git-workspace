/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuron;
import java.util.ArrayList;
/**
 *
 * @author Chen
 */
public class HiddenLayer extends Layer{
    public void initLayer (HiddenLayer hiddenLayer, ArrayList<HiddenLayer> listOfHiddenLayer, InputLayer inputLayer, OutputLayer outputLayer){
        // Initialize the hidden hidden layer(s) with pseudo random real numbers
        
    }
    
public void printLayer(ArrayList<HiddenLayer> listOfHiddenLayer){
    
}


}
