import java.lang.Math;
import java.util.Scanner;

public class Ch04_InClass {
    public static void main(String[] args) {
        // method01();
        // method02_repeatAddition();
        // method03_guess();
        // method04();
        method05();

    }

    public static void method05() {
        Scanner input = new Scanner(System.in);
        int typeNumber = 1;
        int i = 1;
        while (typeNumber != 0) {
            System.out.println("Round No." + i);
            i = i + 1;
            System.out.println("Enter your input integer");
            typeNumber = input.nextInt();
        }
        System.out.println("Since you input 0, the loop stops!!!!");
    }


    public static void method04() {
        int i, num01, num02, answer, grade;
        i = 1;
        grade = 0;
        Scanner input = new Scanner(System.in);
        while (i <= 5) {
            num01 = (int) (Math.random() * 10);
            num02 = (int) (Math.random() * 10);
            System.out.println(num01 + " - " + num02 + " = ");
            answer = input.nextInt();
            if (answer == num01 - num02) {
                grade = grade + 1;
            }
            i = i + 1;
        }
        System.out.println("Grade is " + grade);
    }

    public static void method03_guess() {
        int number1 = (int) (Math.random() * 100);
        System.out.println("Enter");
        Scanner input = new Scanner(System.in);
        int guess = 101;
        while (guess != number1) {
            System.out.println("Enter your guess number");
            guess = input.nextInt();
            if (guess < number1)
                System.out.println("Too low, guess again");
            else
                System.out.println("Too high, guess again");

        }
        System.out.println("Your ar correct! Right Answer is " + number1);
    }

    public static void method02_repeatAddition() {
        int answer = 0;
        int result = 1;
        Scanner input = new Scanner(System.in);
        int number1, number2;
        System.out.println("Enter number 1 (0-9)");
        number1 = input.nextInt();
        System.out.println("Enter number 2 (0-9)");
        number2 = input.nextInt();

        while (answer != result) {
            System.out.println("Enter Answer");
            answer = input.nextInt();
            result = number1 + number2;
            if (result == answer)
                System.out.println("Correct, Finish!");
            else
                System.out.println("Wrong, Continue!");
        }


    }


    public static void method01() {
        Scanner input = new Scanner(System.in);
        char chaTest = 'a';
        System.out.println(++chaTest);
        String str1 = "   Welcome    ";
        System.out.println(str1.trim() + str1.trim());
    }

}

