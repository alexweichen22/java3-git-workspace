public class Ch06_Refactory {
    public static void main(String[] args) {
        // Create a Scanner
        Scanner input = new Scanner(System.in);

        // Read 2 numbers from console
        System.out.println("Enter 2 Numbers");
        int num1, num2, numTemp;
        num1 = input.nextInt();
        num2 = input.nextInt();

        // swam num1 & num2 if num1>num2 (To make sure num1 is always equal or smaller than num2)
        if (num1>num2){
            numTemp=num2;
            num2=num1;
            num1=numTemp;
        }
        // Call checkPrime to check num1 & num2

        // If num1!=prime && num2!=prime, call checkGCD

        // If num1==prime && num2==prime,

        // If num1==prime && num2!=prime

        // If num1!=prime && num2==prime


    }
    public static boolean checkPrime(int i){
    // return true if i is prime && return false if i is not prime
    }
    public static int checkGCD(int x, int y){
    // return GCD of x and y
    }


}