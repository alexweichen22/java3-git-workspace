public class Ch01_05_Display_Math_Results {
    public static void main(String[] args) {
        System.out.println("(9.5X4.5-2.5X3)/(45.5-3.5) = " + ((9.5*4.5)-(2.5*3.0))/(45.5-3.5));
    }
}
