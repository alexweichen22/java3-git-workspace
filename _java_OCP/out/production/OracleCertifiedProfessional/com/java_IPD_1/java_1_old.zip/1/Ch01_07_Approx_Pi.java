import java.lang.Math;
public class Ch01_07_Approx_Pi {
    public static void main(String[] args) {
    // To display pi = 4 ( 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 + ... )
        double i;
        double piApprox_i;
        i=0;
        piApprox_i=0;
        while (i<=5.0){
            piApprox_i = piApprox_i + 4*(Math.pow(-1.0,i)/(2*i+1));
            i=i+1.0;
        }
        System.out.println(piApprox_i);

        double j;
        double piApprox_j;
        j=0;
        piApprox_j=0;
        while (j<=6.0){
            piApprox_j = piApprox_j + 4*(Math.pow(-1.0,j)/(2*j+1));
            j=j+1.0;
        }
        System.out.println(piApprox_j);
    }
}
