//import java.lang.Math;
public class Ch07_Array_Exe {
    public static void main(String[] args) {
        ex01_countLetter();
    }
    public static void ex01_countLetter(){
        // Generate a string of size 100 with random characters
            char[] chars1 = new char[10];
          //  int[] counts = new int['z'-'a'+1];
//            System.out.println(counts.length);
        System.out.println(chars1.length);
            for (int i=0;i<chars1.length;i++){
                chars1[i]='a';
            }
            for (char i: chars1){
                System.out.println(i);
            }


        // Count the amount of each character

        // Display
    }
}

