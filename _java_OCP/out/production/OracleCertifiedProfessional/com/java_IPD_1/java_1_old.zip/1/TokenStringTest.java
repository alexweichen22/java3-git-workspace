package _java_exe.tokenStringTest.src.tokenstringtest;
/*  1.	Write an application that accepts an input line of 
text using the Scanner class, tokenizes the line using space
character as delimiter and outputs only those words beginning 
with the letter "b".
*/
import java.util.Scanner;
import java.util.StringTokenizer;

public class TokenStringTest {

 
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The String");
        String string1 = input.nextLine();
        
        String[] tokens = string1.split(" ");
        for(String st: tokens){
            if (st.startsWith("b",0))
            System.out.println(st);
        }
    }
    
}
