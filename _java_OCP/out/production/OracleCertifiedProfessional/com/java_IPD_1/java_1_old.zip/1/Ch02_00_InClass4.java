import java.util.Scanner;
public class Ch02_00_InClass4 {
    public static void main(String[] args) {
        int number1 = (int)(System.currentTimeMillis()%10);
        int number2 = (int)(System.currentTimeMillis()/10%10);

        // Create a Scanner                                         // Enter an answer, compare and calculate if answer is correct
        Scanner input = new Scanner(System.in);

        System.out.println("What is " + number1 + " + " + number2 + "?");
        int answer = input.nextInt();


//
////        System.out.println(System.currentTimeMillis());
////
////        System.out.println(number1);
////        System.out.println(number2);
    }
}
