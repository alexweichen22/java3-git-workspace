public class Ch02_00_InClass8 {
    public static void main(String[] args) {
        String greeting = "abcdefgh";
        String stringTake = greeting.substring(2,5);
        System.out.println(stringTake);
    }
}
