public class Ch06_PlayUnfamiliarThings {
    public static void main(String[] args) {
        playPrintFormat01();
    }
    public static void playPrintFormat01(){
        System.out.print("123456789\b\n abcdefg\b \n \f sfd\tjjfsd");
        System.out.print("\n      Java!\rHello");
    }
}
