public class Ch02_00_InClass2 {
    public static void main(String[] args) {
        int myInt = 1;
        long myLong = 1;
        double myDouble = 1;
        float myFloat = 1;

        System.out.println(myInt);
        System.out.println(myLong);
        System.out.println(myDouble);
        System.out.println(myFloat);

        float r1 = myLong + myFloat;
        double r2 = myLong + myDouble;
        double r3 = myFloat + myDouble;

        long r4 = myInt + myLong;
        float r5 = myInt + myFloat;
        double r6 = myInt + myDouble;
        double r9 = myInt + myDouble;

        int i = myInt/2;
        System.out.println("1/2 = " + i + "-----------because 1 and 2 are both integer!");

    }
}
