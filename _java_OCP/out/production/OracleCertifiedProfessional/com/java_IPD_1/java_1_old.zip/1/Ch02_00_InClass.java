public class Ch02_00_InClass {
//  Shift Ctr +/- to have higher level View


    public static void main(String[] args) {
//        System.out.println("\n\n...................");
//        int i=0;
//        System.out.println("i = " + i);
//        i++;   // i + 1
//        System.out.println("i = " + i);
//        System.out.println("\n\n..................");
//        System.out.println("i = " + i);
//        System.out.println("i++ = " + i++);
//        System.out.println("i++ in next line = " + i);
//        System.out.println("++i = " + ++i);
//        myTest();

        int i = 10;
        int newNum = 10 * (i++);
        System.out.println(newNum);

        i = 10;
        newNum = 10 * (++i);
        System.out.println(newNum);
    }
//    public static void myTest() {
//        System.out.println("myTest ---- Welcome");
//    }


}
