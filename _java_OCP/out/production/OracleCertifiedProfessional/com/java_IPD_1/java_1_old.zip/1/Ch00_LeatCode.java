//import java.util.Scanner;
//
//public class Ch00_LeatCode {
//    public static void main(String[] args){
//// Enter the size of array & get numbers
////        Scanner input = new Scanner(System.in);
////        System.out.println("Enter the length of number arrays");
////        int lenOfmyArray = input.nextInt();
////        int[] myArray = new int[lenOfmyArray];
//
//        twoSum({1,2,3,4,5,6},7);
//    }
//    public int[] twoSum(int[] nums, int target) {
//// Assume the first answer is the only answer,
//    for (int i=0; i<=)
//
//
//    }
//
//}

