

import java.util.Scanner;
public class Ch03_00_InClass1_CalculateBMI {
    // Body Mass Index (BMI) is Weight (kilos) divided by Square-of-Height (meters).
    // BMI for 16 and + years old:
    // < 18.5 -- Underweight; 18.5<=BMI<25.0 -- Normal;  25.0<=BMI<30.0 Overweight; >=30.0  -- Obese
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double weightInput;
        double heightInput;
        double indexBMI;
        System.out.println("Enter your weight in kilograms");
        weightInput = input.nextDouble();
        System.out.println("Enter your weight in meters");
        heightInput = input.nextDouble();
        indexBMI = weightInput / heightInput / heightInput;

        // Display results
        if (indexBMI < 18.5)
            System.out.println("Underweight");
        else if (indexBMI < 25.0)
            System.out.println("Normal");
        else if (indexBMI < 30.0)
            System.out.println("Overweight");
        else
            System.out.println("Obese");

    }
}
