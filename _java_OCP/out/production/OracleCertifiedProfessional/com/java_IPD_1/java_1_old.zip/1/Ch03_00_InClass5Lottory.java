public class Ch03_00_InClass5Lottory {
    
}
