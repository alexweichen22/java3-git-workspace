public class Ch01_04_Print_A_Table {
    public static void main(String[] args) {
        int aValue;
        aValue=1;
        System.out.println("a    aE2   aE3");
        while (aValue <=4){
            System.out.println((aValue) + "    " +(aValue*aValue)+ "      " +(aValue*aValue*aValue));
            aValue=aValue+1;
        }
    }
}
