package PACKAGE_NAME;

public class Ch06_String_Play {
}
