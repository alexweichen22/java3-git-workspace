import java.sql.SQLOutput;
import java.util.Scanner;
public class Ch03_00_InClass2_Computing_Taxes {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // 1. Ask the marriage status
        System.out.println("Enter your marriage status: 1. Single;  2. Married Jointly; 3. Married Seperately;  4. Head of Household");
        int marriageStatus = input.nextInt();

        // 2. Ask the income
        System.out.println("Enter your income in dollars integer");
        int incomeValue = input.nextInt();

        // 3. Apply situations to relevant tax rate
        switch (marriageStatus)
            {
            case 1:
                if (incomeValue<=8350)
                    System.out.println("10%");
                else if (incomeValue<=33950)
                    System.out.println("15%");
                else if (incomeValue<=82250)
                    System.out.println("25%");
                else if (incomeValue<=171550)
                    System.out.println("38%");
                else if (incomeValue<=372950)
                    System.out.println("33%");
                else
                    System.out.println("35%");
                break;
            case 2:
                if (incomeValue<=16700)
                    System.out.println("10%");
                else if (incomeValue<=67900)
                    System.out.println("15%");
                else if (incomeValue<=813705)
                    System.out.println("25%");
                else if (incomeValue<=2088500)
                    System.out.println("38%");
                else if (incomeValue<=3729500)
                    System.out.println("33%");
                else
                    System.out.println("35%");
                break;

        }
    }
}
