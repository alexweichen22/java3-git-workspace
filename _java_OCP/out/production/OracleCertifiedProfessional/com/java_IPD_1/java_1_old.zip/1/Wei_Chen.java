import java.util.Scanner;
public class Wei_Chen {
    public static void main(String[] args) {
        boolean isOK = true;
//        switch (isOK) {
//            case true:
//                System.out.println("Monday");
//                break;
//            case false:
//                System.out.println("Tuesday");
//                break;
//            default :
//                System.out.println("Wrong");
//                break;
//        }
    }
}
