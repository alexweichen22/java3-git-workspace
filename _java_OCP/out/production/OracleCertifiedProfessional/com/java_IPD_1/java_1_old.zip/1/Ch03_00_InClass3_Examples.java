import java.util.Scanner;
public class Ch03_00_InClass3_Examples {
    public static void main(String[] args) {
        Ch03_00_InClass3_Examples.checkDiv23();

    }
    public static void checkDiv23() {
        Scanner input = new Scanner(System.in);
        int inputValue;
        System.out.println("Enter a integer");
        inputValue = input.nextInt();
        int resultValue=0;
        if ((inputValue%2==0)&&(inputValue%3==0))
            System.out.println("Divisible by both");
        else if (inputValue%2==0)
            System.out.println("Divisible by 2");
        else if (inputValue%3==0)
            System.out.println("Divisible by 3");
        else
            System.out.println("Divisible by neither 2 nor 3");
        }
    }




