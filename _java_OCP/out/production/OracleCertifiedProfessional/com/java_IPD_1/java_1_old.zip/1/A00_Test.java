public class A00_Test {
    public static void main(String[] args) {
        test01_forEach();    //
    }
    public static void test01_forEach(){
        int[] intStr = new int[10];
        for (int i=0; i<10; i++){
            intStr[i] = i;
        }
        int sum=0;
        for(int intTemp: intStr){
        sum=sum+intTemp;
        }
        System.out.println(sum);
    }
}

