import java.util.Scanner;
public class Ch02_00_InClass3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);  // Assign the property of Scanner "class" to input
//        System.out.println((int)3.0);
//        System.out.println((int)3.9);
//        System.out.println((int)(5/2.0));
//        double number1 = input.nextDouble();
//
//        int n ="hello".length();
        System.out.println(12%6/5);



    }
}
