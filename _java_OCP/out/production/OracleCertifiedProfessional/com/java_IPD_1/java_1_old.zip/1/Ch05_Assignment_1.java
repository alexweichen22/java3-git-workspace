import java.lang.Math;
import java.util.Scanner;

public class Ch05_Assignment_1 {
    public static void main(String[] args) {
//        exe05_01();
//        exe05_06();
//        exe05_07();
//.......        exe05_09();
//        exe05_11();
//        exe05_12();
//        exe05_13();
//        exe05_14();
//        exe05_15();
//        exe05_16();
//        exe05_17();
//        exeTA1_printArrow();
//        exe9x9();
//        exesum();
//        exeGCD();
//         exeGCDwhile();
//        exeDoubleTuition();
//          exeGuess();
//       exePalindrome();
 //       exeDisplayPrime();
              exeStringPlay();

    }

    public static void exeStringPlay() {
        // Convert String number to integer
        String string1 = "2555";
        int intFromString = Integer.parseInt(string1);
        System.out.println(intFromString);

        // Convert String number to double
        String string2  = "2555";
        double doubleFromString = Double.parseDouble(string2);
        System.out.println(doubleFromString);

        // Convert number to string
        int number1=105;
        String string3=number1+"";
        System.out.println(number1);
        System.out.println(string3.charAt(2));
    }

    public static void exeDisplayPrime() {
        int primeCount = 0;
        for (int i = 2; i <= 1000; i++) {
            int count = 0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) count = count + 1;
            }
            if (count <= 2) {
                primeCount = primeCount + 1;
                System.out.printf("%4d", i);
                if (primeCount == 50) break;
                if (primeCount % 10 == 0) System.out.println();

            }

        }
    }

    public static void exePalindrome() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your string for Palindrome check (no space)");
        String stringInput = input.next();
        int stringLen = stringInput.length();
        boolean isPad = true;
        for (int i = 0; i <= (int) (stringLen - 1); i++) {
            if (stringInput.charAt(0 + i) != stringInput.charAt(stringLen - 1 - i)) {
                isPad = false;
                break;
            }

        }
        if (isPad == true) System.out.println("Yes it is palindrome");
        else System.out.println("No it is not palindrome");
    }

    public static void exeGuess() {
        Scanner input = new Scanner(System.in);
        int result = (int) (Math.random() * 10);
        int guess = 111;

        while (true) {
            System.out.println("Enter Your Guess");
            guess = input.nextInt();
            if (guess < result) System.out.println("Your guess is too small");
            if (guess > result) System.out.println("Your guess is too high");
            if (result == guess) break;
        }
        System.out.println("Congratulations! You are right");
        System.out.printf("The Number is %2d\n", result);
        System.out.printf("Your Guess is %2d\n", guess);
    }

    public static void exeDoubleTuition() {
        double tuition = 10000;
        int i = 0;

        while (tuition <= 20000) {
            tuition = 10000 + 10000 * i * 0.07;
            System.out.printf("Year %d, Tuition Fee %.1f\n", i, tuition);
            i = i + 1;
        }

    }

    public static void exeGCDwhile() {

    }

    public static void exeGCD() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter  integer number1");
        int number1 = input.nextInt();
        System.out.println("Enter  integer number2");
        int number2 = input.nextInt();
        int numbertemp;
        if (number1 > number2) {
            numbertemp = number2;
            number2 = number1;
            number1 = numbertemp;
        }
        int GCD = 1;
        int GCD1 = 1;

        for (int i = 1; i <= number1; i++) {
            if (number1 % i == 0) GCD1 = i;
            for (int j = 1; j <= number1; j++) {
                if (number2 % GCD1 == 0) GCD = GCD1;
            }
        }
        System.out.println(GCD);
    }


    public static void exesum() {
        double sum = 0;
        for (int i = 1; i <= 100; i++) {
            sum = sum + 0.01 * i;
        }
        System.out.printf("0.01 + 0.02 + 0.03 + ... + 0.98 + 0.99 + 1.00 = \n%.2f", sum);
    }

    public static void exe9x9() {
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= i; j++) {
                int result;
                result = i * j;
                System.out.printf("%4d", result);
            }
            System.out.println("");
        }
        System.out.println("\n\n");
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= 9; j++) {
                int result;
                result = i * j;
                System.out.printf("%4d", result);
            }
            System.out.println("");
        }
    }

    public static void exe05_01() {
        //        (Count positive and negative numbers and compute the average of numbers) Write
        //        a program that reads an unspecified number of integers, determines how many
        //        positive and negative values have been read, and computes the total and average of
        //        the input values (not counting zeros). Your program ends with the input 0. Display
        //        the average as a floating-point number. Here is a sample run:
        //        Enter:  1 2 -1 3 0  ---- Number of positives=3, Number of negatives=1, Total=5, Average=1.25  [(1+2-1+3)/4]
        //        Enter: 0  =         ---- No numbers entered!!!!
        //----------------------------------------------------------------

        //  0. Initial Setup
        Scanner input = new Scanner(System.in);
        int number = 1;
        int count = 0;
        int sum = 0;
        int noneZeroCount = 0;

        //  1. Conversation with users (Ask to enter, take the input)
        while (true) {
            System.out.println("Enter a integer, 0 to finish!");
            number = input.nextInt();
            sum = sum + number;
            count = count + 1;
            if (number == 0) break;
            noneZeroCount = noneZeroCount + 1;
        }

        //  2. Calculate &  Display
        int average;
        System.out.println("Total count is " + count);
        if (count == 1) {
            System.out.println("You have no input");
        } else {
            average = sum / noneZeroCount;
            System.out.println("The average is " + average);
        }
    }


    public static void exe05_06() {
        int i = 1;
        int col1, col3;
        double col2, col4;
        System.out.println("Miles    Kilometers   |    Kilometers      Miles");
        while (i <= 10) {
            col1 = i;
            col3 = col1 * 5 + 15;
            col2 = col1 * 1.60934;
            col4 = col3 * 0.621371;
            System.out.printf(" %d            %.3f   |    %d              %.3f    \n", col1, col2, col3, col4);
            i++;
        }
    }

    public static void exe05_07() {
//        5.7 (Financial application: compute future tuition) Suppose that the tuition for a university
//        is $10,000 this year and increases 5% every year. In one year, the tuition
//        will be $10,500. Write a program that computes the tuition in ten years and the
//        total cost of four years’ worth of tuition after the tenth year.
        int year = 0;
        double tuition = 10000.0;
        double totalTuition = 0.0;
        while (++year <= 14) {
            tuition *= 1.05;
            if (year <= 10)
                System.out.printf("Tuition of Year No. %d is %.0f $\n", year, tuition);
            else
                totalTuition = totalTuition + tuition;
        }
        System.out.printf("\nTotal 4 years tuition fees in 10 years (Year 11 to Year 14) is %.2f$ \n", totalTuition);
    }

    public static void exe05_09() {
//        *5.9 (Find the two highest scores) Write a program that prompts the user to enter the
//        number of students and each student’s name and score, and finally displays the
//        student with the highest score and the student with the second-highest score.

        // 1. Prepare
        String name = "", name1st = "", name2nd = "", nameTemp = "";
        int score = 0, score1st = 0, score2nd = 0, scoreTemp = 0, creteria = 1;
        Scanner input = new Scanner(System.in);

        // 2. Read Input & Calculation
        while (true) {
            System.out.println("Enter Student Name");
            name = input.next();
            System.out.printf("Enter the Score of %s \n", name);
            score = input.nextInt();

            // Assume All Scores Are different
            if (score > score1st) {
                score2nd = score1st;
                score1st = score;
                name2nd = name1st;
                name1st = name;
            } else if (score < score1st && score > score2nd) {
                score2nd = score;
                name2nd = name;
            } else
                continue;

            System.out.println("Do you want to Continue? Enter 1 for yes, Enter 0 for no!");
            creteria = input.nextInt();
            if (creteria == 0) break;


        }

    }

    public static void exe05_11() {

    }

    public static void exe05_12() {

    }

    public static void exe05_13() {

    }

    public static void exe05_14() {

    }

    public static void exe05_15() {

    }

    public static void exe05_16() {

    }

    public static void exe05_17() {

    }

    public static void exeTA1_printArrow() {
        int i = 1;
        int k = 1;
        while (i <= 20) {
            while (k <= i) {
                System.out.print("*");
                k++;
            }
            k = 1;
            System.out.println();
            i++;
        }
    }

}
