import java.sql.SQLOutput;
import java.util.Scanner;
public class Ch03_00_InClass4_LeapYear {
    public static void main(String[] args) {

    }
    public static void checkLeap() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter integer year");
        int year = input.nextInt();

//        year % 4 == 0 && year%100!=0)||(year%400==0)
    }

}
