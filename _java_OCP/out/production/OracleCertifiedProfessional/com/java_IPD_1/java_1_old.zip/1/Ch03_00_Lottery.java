import java.lang.Math;
import java.sql.SQLOutput;
import java.util.Scanner;

import static java.lang.System.currentTimeMillis;

public class Ch03_00_Lottery {
    //    Problem: Lottery
//    Write a program that randomly generates a lottery of a two digit number, prompts the user to enter a two-digit number,
//    and determines whether the user wins according to the
//    following rule:
//            • If the user input matches the lottery in exact order, the
//    award is $10,000.
//            • If the user input digits matches the lottery digits in
//    different order, the award is $3,000.
//            • If one digit in the user input matches a digit in the
//    lottery, the award is $1,000.
    public static void main(String[] args) {
        lotteryCal();
    }
    public static void lotteryCal() {
        int numberWin=(int)(Math.random()*100);
        int digitOne = numberWin%10;
        int digitTen = (int)((numberWin/10)%10);
        System.out.println(numberWin);
        System.out.println(digitTen);
        System.out.println(digitOne);

        int numberInput;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your guess of 2 digits integer");
        numberInput = input.nextInt();
        int guessOne = (int)(numberInput%10);
        int guessTen = (int)((numberInput/10)%10);
        System.out.println(numberInput);
        System.out.println(guessTen);
        System.out.println(guessOne);

        System.out.println(numberWin);
        if (digitOne==guessOne && digitTen==guessTen)
            System.out.println("You Win $10,000");
        else if (digitTen==guessOne && digitOne==guessTen)
            System.out.println("You Win $3,000");
        else if (digitOne==guessTen ||digitTen==guessOne)
            System.out.println("You Win $1,000");
        else
            System.out.println("Play Again");
    }
}
