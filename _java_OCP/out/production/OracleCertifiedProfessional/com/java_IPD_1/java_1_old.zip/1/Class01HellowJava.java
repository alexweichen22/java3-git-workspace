import java.sql.SQLOutput;

public class Class01HellowJava {
    public static void main(String[] args) {
        System.out.println("Welcome to Java");
        System.out.println((10.5+2/3)/(45-3.5));
        System.out.println((10.5)/(45.0-3.5));
        System.out.println((10.5+2.0/3.0)/(45.0-3.5));
    }
}

