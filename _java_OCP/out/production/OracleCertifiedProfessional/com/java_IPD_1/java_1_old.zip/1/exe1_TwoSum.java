/*  ---------------------------------------------
Given an array of integers, return indices of the two numbers such that they add up to a specific target.

        You may assume that each input would have exactly one solution, and you may not use the same element twice.

        Example:

        Given nums = [2, 7, 11, 15], target = 9,

        Because nums[0] + nums[1] = 2 + 7 = 9,
        return [0, 1].

 --------------------------------------------- */

class exe1_TwoSum {
    public static void main(String[] args) {
        int[] intInput = new int[5];
        for(int i=0;i<5;i++){
            intInput[i]=i*2+1;
        }
        twoSum(intInput[], 5);
    }
    public int[] twoSum(int[] nums, int target) {
        int complement;
        //loop to check every element in the array
        for (int x = 0; x<nums.length; x++) {
            complement = target - nums[x];
            //loop to find complement of current element
            for (int y = 0; y<nums.length; y++) {
                //we cannot use same element twice.
                if (x ==  y) { continue; }
                if (nums[y] == complement) {
                    return new int[] {x, y};
                }
            }
        }
        return new int[] {0, 0};
    }
}
