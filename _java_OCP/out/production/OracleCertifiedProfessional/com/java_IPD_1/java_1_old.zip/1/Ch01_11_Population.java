public class Ch01_11_Population {
    public static void main(String[] args) {
        int nYear;
        int populationPresnt=312032486;
        nYear = 1;
        for (nYear=1; nYear<= 5; nYear=nYear+1) {
            System.out.println((populationPresnt+nYear*365*24*3600*(1.0/7.0-1.0/13.0+1.0/45.0)));
                    }
    }
}