public class Ch02_00_InClass5 {
    public static void main(String[] args) {
        String greeting = "Hello";
        int n = greeting.length();
        System.out.println(n);
    }
}
