import java.util.Scanner;
public class Ch02_00_InClass7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // 1. Generate Two Random single-digit integers
        int randomInt1 = (int)(System.currentTimeMillis()%10);
        int randomInt2 = (int)(System.currentTimeMillis()/10%10);

        // 2. If number1 < number2, swap number1 with number2
        int randomEmpty;
        if (randomInt1 < randomInt2) {
            randomEmpty = randomInt1;
            randomInt1 = randomInt2;
            randomInt2 = randomEmpty;
        }

        // 3. Prompt the student to answer ?what is number1? what is number 2?
        System.out.println("What is the answer of " + randomInt1 + " - " + randomInt2 + " = ");

        // 4. Grade the result, and display
        int answer = input.nextInt();
        int result = randomInt1-randomInt2;
        if (answer == result)
            {System.out.println("Correct!");}
            else
                {System.out.println("Wrong!");}
    }
}
