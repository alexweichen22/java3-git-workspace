import java.util.Scanner;
public class Ch02_00_InClass6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int number1 = input.nextInt();
        System.out.println(number1);
        if (number1%5 == 0) {
            System.out.println("HiFive");
        }
        if (number1%2 == 0) {
            System.out.println("HiEven");
        }

    }
}
